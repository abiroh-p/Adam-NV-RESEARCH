import glob, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family":"serif","font.size":8,"axes.labelsize":8,"legend.fontsize":7,"xtick.labelsize":7,"ytick.labelsize":7,
                     "axes.linewidth":0.6,"lines.linewidth":1.0,"pdf.fonttype":42,"ps.fonttype":42})
ORIG='/home/claude/repo/e2_noisy_gradient/logs/Label_Diagnostic'
E7='/home/claude/e7'; E8='/home/claude/e8'
NAME="{opt}_scheduleconstant_sigma0.0_ln0.2_seed{seed}.csv"
dirs={'adam':([ORIG,E7+'/A/logs_exp07_A',E7+'/B/logs_exp07_B'],'adam'),
      'nv':([ORIG,E7+'/C/exp07_log_C/log_exp07_C'],'adam_nv'),
      'c081':([E7+'/A/logs_exp07_A',E7+'/B/logs_exp07_B'],'adam_nv_fixed'),
      'c078':([E8+'/A/logs_exp08_b078_A',E8+'/B/exp08_logs_B/logs_exp08_b078_B'],'adam_nv_fixed'),
      'c070':([E8+'/A/logs_exp08_b070_A',E8+'/B/exp08_logs_B/logs_exp08_b070_B',E8+'/C/logs_exp08_b070_C'],'adam_nv_fixed')}
def load(k):
    ds,opt=dirs[k]; out={}
    for s in range(8):
        for d in ds:
            p=os.path.join(d,NAME.format(opt=opt,seed=s))
            if os.path.isfile(p):
                df=pd.read_csv(p); assert len(df)==60; out[s]=df; break
    assert len(out)==8,(k,len(out)); return out
R={k:load(k) for k in dirs}
SM='adam_nv_scheduleconstant_sigma0.0_responsesmooth_betamax0.999_ln0.2_seed{s}.csv'
R['smooth']={}
R['shstep']={}; R['shfixed']={}; R['tm']={}; R['c092']={}; R['c095']={}
for s_ in range(8):
    dT='/home/claude/e13/A/logs_exp13_tm_A' if s_<4 else '/home/claude/e13/B/logs_exp13_tm_B'
    R['tm'][s_]=pd.read_csv(os.path.join(dT,'adam_nv_scheduleconstant_sigma0.0_ln0.2_seed%d.csv'%s_))
for s_ in range(8):
    d92='/home/claude/e12/1/logs_exp12_b092_1' if s_<4 else '/home/claude/e12/2/logs_exp12_b092_2'
    d95='/home/claude/e12/3/logs_exp12_b095_1' if s_<4 else '/home/claude/e12/4/logs_exp12_b095_2'
    R['c092'][s_]=pd.read_csv(os.path.join(d92,'adam_nv_fixed_scheduleconstant_sigma0.0_ln0.2_seed%d.csv'%s_))
    R['c095'][s_]=pd.read_csv(os.path.join(d95,'adam_nv_fixed_scheduleconstant_sigma0.0_ln0.2_seed%d.csv'%s_))
for s_ in range(8):
    dA='/home/claude/e11/A/logs_exp11_step_A' if s_<6 else '/home/claude/e11/C/logs_exp11_step_C'
    dB='/home/claude/e11/B/logs_exp11_fixed_B' if s_<6 else '/home/claude/e11/C/logs_exp11_fixed_C'
    R['shstep'][s_]=pd.read_csv(os.path.join(dA,'adam_nv_scheduleconstant_sigma0.0_ln0.2_seed%d.csv'%s_))
    R['shfixed'][s_]=pd.read_csv(os.path.join(dB,'adam_nv_scheduleconstant_sigma0.0_ln0.2_seed%d.csv'%s_))
for s in range(8):
    d9='/home/claude/e9/A/logs_exp09_A' if s<4 else '/home/claude/e9/B/logs_exp09_B'
    df=pd.read_csv(os.path.join(d9,SM.format(s=s))); assert len(df)==60; R['smooth'][s]=df

lab={'smooth':'Adam-NV, smooth response','adam':r'Adam ($\beta_1$=0.90)','c081':r'const. $\beta_1$=0.81','c078':r'const. $\beta_1$=0.78','c070':r'const. $\beta_1$=0.70','nv':'Adam-NV'}
sty={'smooth':dict(color='0.30',ls=(0,(1,1)),lw=1.6),'adam':dict(color='0.15',ls='-'),'c081':dict(color='0.45',ls='--'),'c078':dict(color='0.55',ls='-.'),'c070':dict(color='0.65',ls=':'),'nv':dict(color='black',ls='-',lw=1.8)}
order=['adam','c081','c078','c070','smooth','nv']
# --- Fig 1: memorization trajectory + per-seed last-5
fig,ax=plt.subplots(1,2,figsize=(7.1,2.35),gridspec_kw={'width_ratios':[1.35,1]})
ep=np.arange(1,61)
for k in order:
    M=np.mean([R[k][s].train_corrupt_noisy_label_acc.values for s in R[k]],axis=0)*100
    kw=dict(sty[k]); lw=kw.pop('lw',1.0)
    ax[0].plot(ep,M,label=lab[k],lw=lw,**kw)
ax[0].set_xlabel('Epoch'); ax[0].set_ylabel('Corrupted labels memorized (%)'); ax[0].set_xlim(1,60); ax[0].legend(frameon=False,loc='upper left'); ax[0].set_title('(a) Mean over 8 seeds',fontsize=8)
rng=np.random.default_rng(0)
order_b=['c070','c078','c081','adam','c092','c095','smooth','shstep','shfixed','tm','nv']
for i,k in enumerate(order_b):
    v=np.array([R[k][s].train_corrupt_noisy_label_acc.tail(5).mean()*100 for s in sorted(R[k])])
    ax[1].scatter(i+rng.uniform(-0.12,0.12,len(v)),v,s=9,color='0.35',zorder=3)
    ax[1].hlines(v.mean(),i-0.3,i+0.3,color='black',lw=1.4,zorder=4)
ax[1].set_xticks(range(11)); ax[1].set_xticklabels([r'.70',r'.78',r'.81',r'Adam',r'.92',r'.95','smooth','shuf.\nstep','shuf.\nfixed','tens.\nmean','NV'],fontsize=5.2)
ax[1].set_xlabel(r'const. $\beta_1$ (0.70 to 0.95) | smooth | shuffled / tensor mean | NV',fontsize=6); ax[1].set_ylabel('Last-5-epoch mean (%)'); ax[1].set_title('(b) Per seed (dots), mean (bar)',fontsize=8)
for a in ax: a.tick_params(length=2.5)
plt.tight_layout(); plt.savefig('figs/fig_memorization.pdf'); plt.close()
# --- Fig 2: Adam-NV beta1 trajectory
fig,ax=plt.subplots(figsize=(3.45,2.3))
B=np.mean([R['nv'][s].beta1_mean.values for s in R['nv']],axis=0); Bm=np.mean([R['nv'][s].beta1_min.values for s in R['nv']],axis=0)
ax.plot(ep,B,color='black',lw=1.6,label=r'Adam-NV: mean $\beta_1$ (over tensors)')
ax.plot(ep,Bm,color='0.45',ls='--',label=r'Adam-NV: lowest per-tensor mean $\beta_1$')
Bs=np.mean([R['smooth'][s].beta1_mean.values for s in R['smooth']],axis=0)
ax.plot(ep,Bs,color='0.3',ls=(0,(1,1)),lw=1.6,label=r'smooth response: mean $\beta_1$ (over tensors)')
for c,l in [(0.81,'0.81'),(0.78,'0.78'),(0.70,'0.70')]:
    ax.axhline(c,color='0.7',lw=0.6,ls=':'); ax.text(61,c,l,va='center',fontsize=6,color='0.35')
ax.axhline(0.9,color='0.15',lw=0.8); ax.text(61,0.9,'0.90',va='center',fontsize=6)
ax.set_xlabel('Epoch'); ax.set_ylabel(r'$\beta_1$'); ax.set_xlim(1,60); ax.set_ylim(0.4,1.0); ax.legend(frameon=False,loc='lower center',fontsize=6.5); ax.tick_params(length=2.5)
plt.tight_layout(); plt.savefig('figs/fig_beta1.pdf'); plt.close()
# print numbers used in text
print('beta1 mean epoch1,20,60:',B[0].round(3),B[19].round(3),B[59].round(3),' mean lowest-element beta1:',Bm.mean().round(3))
for k in order:
    v=np.array([R[k][s].train_corrupt_noisy_label_acc.tail(5).mean()*100 for s in sorted(R[k])]); print(k,round(v.mean(),2),round(v.std(ddof=1),2))
