"""Recompute every Experiment 14 (tensor-subset) number typed in main.tex from the raw logs.

Same convention as verify_paper_numbers.py: chk(name, computed, paper, tol) prints OK/XX and collects mismatches.
Run:  E14_ROOT=<folder holding the log folders> python3 verify_e14_numbers.py
Expected layout under E14_ROOT (as uploaded):
  Label_Diagnostic/                      adam, adam_nv seeds 0-3 (original 20%-label-noise logs)
  logs_exp07_A, logs_exp07_B             adam seeds 4-7
  exp07_log_C/log_exp07_C                adam_nv seeds 4-7
  logs_exp14_onedim_A, logs_exp14_onedim_C   adam_nv, controller on rank<=1 tensors only (seeds 0-5 / 6-7)
  logs_exp14_rest_B,   logs_exp14_rest_C     adam_nv, controller on rank>=2 tensors only (seeds 0-5 / 6-7)
"""
import os, sys, itertools
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import analyze_exp07 as e7

R = os.environ.get("E14_ROOT", "/home/claude/e14")
BAD = []
def chk(name, actual, expected, tol=0.006):
    ok = abs(actual - expected) <= tol
    if not ok: BAD.append((name, actual, expected))
    print(f"{'OK ' if ok else 'XX '} {name}: computed {actual:.4f} | paper {expected}")

def load(opt, dirs):
    out = {}
    for s in range(8):
        for d in dirs:
            p = os.path.join(R, d, e7.NAME.format(opt=opt, seed=s))
            if os.path.isfile(p):
                df = pd.read_csv(p); assert len(df) == 60 and list(df.epoch) == list(range(1, 61)), p
                assert not df.isna().any().any(), p
                out[s] = df; break
    assert len(out) == 8, (opt, sorted(out)); return out

base = ["Label_Diagnostic", "logs_exp07_A", "logs_exp07_B", "exp07_log_C/log_exp07_C"]
arms = {"adam": load("adam", base), "nv": load("adam_nv", base),
        "one": load("adam_nv", ["logs_exp14_onedim_A", "logs_exp14_onedim_C"]),
        "rest": load("adam_nv", ["logs_exp14_rest_B", "logs_exp14_rest_C"])}
METR = {"mem5": e7.METRICS["mem5"][1], "val5": e7.METRICS["val5"][1], "clean5": e7.METRICS["clean5"][1], "valpeak": e7.METRICS["valpeak"][1]}
tab = {a: {m: {s: f(df) for s, df in arms[a].items()} for m, f in METR.items()} for a in arms}
def con(a, b, m="mem5"): return e7.contrast({"a": tab[a][m], "b": tab[b][m]}, "a", "b")

# ---- Table IX rows for the two subset arms
for k, (mm, sd, val, cl, dl, lo, hi, up) in {"one": (80.78, 0.52, 78.63, 98.78, 1.19, 0.50, 1.88, 7), "rest": (82.31, 0.83, 78.59, 98.82, 2.73, 1.97, 3.49, 8)}.items():
    v = np.array([tab[k]["mem5"][s] for s in range(8)])
    chk(f"T9 {k} mem", v.mean(), mm); chk(f"T9 {k} sd", v.std(ddof=1), sd)
    chk(f"T9 {k} val", np.mean(list(tab[k]["val5"].values())), val); chk(f"T9 {k} clean", np.mean(list(tab[k]["clean5"].values())), cl)
    r = con(k, "adam"); chk(f"T9 {k} delta", r["mean"], dl); chk("  lo", r["lo"], lo, 0.0051); chk("  hi", r["hi"], hi, 0.0051); chk("  up", r["up"], up, 0)
# existing rows these contrasts rely on (must still reproduce Table IX)
chk("T9 adam mem", np.mean(list(tab["adam"]["mem5"].values())), 79.58); chk("T9 nv mem", np.mean(list(tab["nv"]["mem5"].values())), 83.49)
M = con("nv", "adam"); chk("M", M["mean"], 3.91); chk("M lo", M["lo"], 3.11, 0.0051); chk("M hi", M["hi"], 4.71, 0.0051)

# ---- registered family {F1,F2,D1,D2}, Holm over the four (primary metric)
pairs = [("one", "adam"), ("rest", "adam"), ("nv", "one"), ("nv", "rest")]
rs = [con(a, b) for a, b in pairs]; adj = e7.holm([r["p"] for r in rs])
for (a, b), r, h, (mean, lo, hi, hp) in zip(pairs, rs, adj, [(1.19, .50, 1.88, .009), (2.73, 1.97, 3.49, .0002), (2.72, 2.24, 3.19, .001), (1.18, .50, 1.86, .009)]):
    chk(f"{a}-{b} mean", r["mean"], mean); chk("  lo", r["lo"], lo, 0.0051); chk("  hi", r["hi"], hi, 0.0051)
    if a == "nv" and b == "one": print(f"INFO D1 Holm p = {h:.2e} (paper: < 0.001)"); assert h < 0.001
    else: chk("  Holm p", h, hp, 0.0006)
chk("D1 up", rs[2]["up"], 8, 0); chk("D2 up", rs[3]["up"], 8, 0)
F1, F2 = rs[0]["mean"], rs[1]["mean"]
chk("F1/M %", 100 * F1 / M["mean"], 30, 0.6); chk("F2/M %", 100 * F2 / M["mean"], 70, 0.6); chk("F1+F2", F1 + F2, 3.92, 0.0051)
print("rule: F1>=0.75M", F1 >= .75 * M["mean"], "| F2>=0.75M", F2 >= .75 * M["mean"], "| CI(D1) incl 0", rs[2]["lo"] <= 0 <= rs[2]["hi"], "| CI(D2) incl 0", rs[3]["lo"] <= 0 <= rs[3]["hi"])
assert not (F1 >= .75 * M["mean"]) and not (F2 >= .75 * M["mean"])   # => outcome 3 'both subsets contribute'

# ---- validation accuracy contrasts quoted in the text
for k, (mean, lo, hi) in {"one": (-0.16, -0.49, 0.17), "rest": (-0.20, -0.64, 0.24)}.items():
    r = con(k, "adam", "val5"); chk(f"val {k}-adam", r["mean"], mean); chk("  lo", r["lo"], lo, 0.0051); chk("  hi", r["hi"], hi, 0.0051)

# ---- exploratory: interaction (2x2 factorial), not part of the registered family
I = np.array([tab["one"]["mem5"][s] + tab["rest"]["mem5"][s] - tab["nv"]["mem5"][s] - tab["adam"]["mem5"][s] for s in range(8)])
from scipy import stats
m = I.mean(); se = I.std(ddof=1) / np.sqrt(8); t = stats.t.ppf(.975, 7)
chk("interaction mean", m, 0.01); chk("  lo", m - t * se, -0.84, 0.0051); chk("  hi", m + t * se, 0.87, 0.0051)
chk("interaction half-width % of M", 100 * t * se / M["mean"], 22, 0.6); chk("half-width pp", t * se, 0.85, 0.0051)

# ---- exploratory: Holm over all 5 contrasts x 4 metrics (20) -> F1, D2 adjusted p
fam = []
for mk in METR:
    for nm, (a, b) in {"M": ("nv", "adam"), "F1": ("one", "adam"), "F2": ("rest", "adam"), "D1": ("nv", "one"), "D2": ("nv", "rest")}.items():
        fam.append((mk, nm, con(a, b, mk)["p"]))
adj20 = dict(zip([(x[0], x[1]) for x in fam], e7.holm([x[2] for x in fam])))
chk("Holm-20 F1", adj20[("mem5", "F1")], 0.075, 0.0006); chk("Holm-20 D2", adj20[("mem5", "D2")], 0.075, 0.0006)
print("INFO Holm-20 others:", {k: round(float(v), 4) for k, v in adj20.items() if k[0] == "mem5"})
chk("Holm-20 F2 (text: at most 0.0012)", adj20[("mem5", "F2")], 0.0012, 0.00006); chk("Holm-20 M", adj20[("mem5", "M")], 0.0002, 0.00006); chk("Holm-20 D1", adj20[("mem5", "D1")], 0.0001, 0.00006)
assert max(adj20[("mem5", k)] for k in ("M", "F2", "D1")) <= 0.0012 + 1e-4
assert adj20[("mem5", "F2")] < 0.05 and adj20[("mem5", "D1")] < 0.05 and adj20[("mem5", "M")] < 0.05

# ---- subset sizes and logged beta1 in the active subset (equal weight per tensor; plain tensors at 0.9)
chk("1-D share of elements %", 100 * 9610 / 11173962, 0.09, 0.0051)
und = {"one": lambda b: (62 * b - 21 * 0.9) / 41, "rest": lambda b: (62 * b - 41 * 0.9) / 21}
for k, v in {"one": 0.75, "rest": 0.84}.items():
    chk(f"undiluted beta1 {k} epoch 60", np.mean([und[k](arms[k][s].beta1_mean.iloc[59]) for s in range(8)]), v, 0.0051)
print("\nMISMATCHES:", len(BAD))
for x in BAD: print(x)
sys.exit(1 if BAD else 0)
