"""Recompute every Experiment 15 (label-noise 10% and 40%) number typed in main.tex from the raw logs.
Run:  E15_ROOT=<folder with the four exp15 log folders> E14_ROOT=<folder with the 20%-noise logs> python3 verify_e15_numbers.py
E15 folders: logs_exp15_ln01_1, exp15_logs_2 (10%, seeds 0-2 / 3-5); exp15_logs_3, exp15_logs_4 (40%, seeds 0-2 / 3-5).
20%-noise reference (8 seeds): Label_Diagnostic, logs_exp07_A, logs_exp07_B, exp07_log_C/log_exp07_C under E14_ROOT.
"""
import os, sys, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp07 as e7
R15 = os.environ.get("E15_ROOT", "/home/claude/e15"); R14 = os.environ.get("E14_ROOT", "/home/claude/e14")
BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
D = {"0.1": ["logs_exp15_ln01_1", "exp15_logs_2"], "0.4": ["exp15_logs_3", "exp15_logs_4"]}
def load(opt, ln):
    out = {}
    for s in range(6):
        for d in D[ln]:
            p = f"{R15}/{d}/{opt}_scheduleconstant_sigma0.0_ln{ln}_seed{s}.csv"
            if os.path.isfile(p):
                df = pd.read_csv(p); assert len(df) == 60 and list(df.epoch) == list(range(1, 61)) and not df.isna().any().any(), p; out[s] = df; break
    assert len(out) == 6, (opt, ln, sorted(out)); return out
res = {}; adamm = {}
for ln, (m, lo, hi, vm, vlo, vhi) in {"0.1": (1.41, .38, 2.44, .11, -.21, .43), "0.4": (2.66, 1.78, 3.53, -.28, -1.21, .65)}.items():
    A, N = load("adam", ln), load("adam_nv", ln)
    mem = {k: {s: e7.METRICS["mem5"][1](d) for s, d in v.items()} for k, v in (("a", A), ("n", N))}
    val = {k: {s: e7.METRICS["val5"][1](d) for s, d in v.items()} for k, v in (("a", A), ("n", N))}
    r = e7.contrast({"n": mem["n"], "a": mem["a"]}, "n", "a"); res[ln] = r
    chk(f"{ln} M", r["mean"], m); chk("  lo", r["lo"], lo, .0051); chk("  hi", r["hi"], hi, .0051); chk("  up", r["up"], 6, 0)
    v = e7.contrast({"n": val["n"], "a": val["a"]}, "n", "a"); chk("  val M", v["mean"], vm); chk("  val lo", v["lo"], vlo, .0051); chk("  val hi", v["hi"], vhi, .0051)
    adamm[ln] = np.mean(list(mem["a"].values()))
adj = e7.holm([res["0.1"]["p"], res["0.4"]["p"]]); chk("Holm p 10%", adj[0], 0.017, .0006); chk("Holm p 40%", adj[1], 0.001, .0006)
adjf = e7.holm([res["0.1"]["pflip"], res["0.4"]["pflip"]]); chk("exact sign-flip Holm (both)", adjf[0], 0.0625, 1e-9); chk("  40%", adjf[1], 0.0625, 1e-9)
d10 = [(e7.METRICS["mem5"][1](load("adam_nv", "0.1")[s]) - e7.METRICS["mem5"][1](load("adam", "0.1")[s])) for s in range(6)]
print("INFO per-seed M at 10%:", np.round(d10, 2).tolist(), "-> min", round(min(d10), 2)); assert min(d10) < 0.1   # 'one seed shows no difference'
# 20% reference: Adam baseline over 8 seeds and M (paper Table IX)
base = [os.path.join(R14, d) for d in ["Label_Diagnostic", "logs_exp07_A", "logs_exp07_B", "exp07_log_C/log_exp07_C"]]
def l20(opt):
    o = {}
    for s in range(8):
        for d in base:
            p = os.path.join(d, e7.NAME.format(opt=opt, seed=s))
            if os.path.isfile(p): o[s] = e7.METRICS["mem5"][1](pd.read_csv(p)); break
    return o
a20, n20 = l20("adam"), l20("adam_nv"); chk("20% M (8 seeds)", e7.contrast({"n": n20, "a": a20}, "n", "a")["mean"], 3.91)
chk("Adam baseline 10% (rounded 91)", adamm["0.1"], 91, .5); chk("Adam baseline 20% (rounded 80)", np.mean(list(a20.values())), 80, .5); chk("Adam baseline 40% (rounded 64)", adamm["0.4"], 64, .5)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
