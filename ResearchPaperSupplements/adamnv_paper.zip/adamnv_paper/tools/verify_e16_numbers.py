"""Recompute every Experiment 16 (noise-proxy diagnostic) number typed in main.tex.
Run: E16_ROOT=<folder with exp16/ (proxy_diag_*.jsonl, proxy_train_*.csv)> E14_ROOT=<folder with Label_Diagnostic/> python3 verify_e16_numbers.py
The jsonl files hold the already-computed correlations (per-element data were not stored), so this verifies the aggregation and the
simulation-based statements, not the element-level correlation computation itself (that is covered by the unit tests against scipy).
"""
import os, sys, json, numpy as np, pandas as pd
from scipy import stats
R16 = os.environ.get("E16_ROOT", "/home/claude/e16"); R14 = os.environ.get("E14_ROOT", "/home/claude/e14")
BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
recs = {(ln, s): [json.loads(x) for x in open(f"{R16}/exp16/proxy_diag_ln{ln}_seed{s}.jsonl") if x.strip()] for ln in ("0.0", "0.2") for s in (0, 1)}
for k, v in recs.items(): assert [r["epoch"] for r in v] == [1, 5, 10, 20, 30, 45, 60] and all(r["k_batches"] == 16 for r in v), k
def sel(ln, lo=5): return [r for s in (0, 1) for r in recs[(ln, s)] if r["epoch"] >= lo]
def at(ln, e, key, seed=None): return np.mean([r[key] for s in (0, 1) for r in recs[(ln, s)] if r["epoch"] == e and (seed is None or s == seed)])
# registered rule
for ln, (r, c) in {"0.0": (0.34, 0.10), "0.2": (0.08, 0.04)}.items():
    chk(f"rule r noise {ln}", np.mean([x["spearman_s_q"] for x in sel(ln)]), r); chk("  c", np.mean([x["spearman_s_scale"] for x in sel(ln)]), c)
    assert abs(np.mean([x["spearman_s_scale"] for x in sel(ln)])) < np.mean([x["spearman_s_q"] for x in sel(ln)])   # 'not scale-confounded by the rule'
# pooled values
chk("clean pooled epoch 5", at("0.0", 5, "spearman_s_q"), 0.03); chk("clean pooled epoch 60", at("0.0", 60, "spearman_s_q"), 0.79)
chk("  seed 0 epoch 60", at("0.0", 60, "spearman_s_q", 0), 0.79); chk("  seed 1 epoch 60", at("0.0", 60, "spearman_s_q", 1), 0.80)
chk("noise pooled epoch 20", at("0.2", 20, "spearman_s_q"), 0.19)
vals = [r["spearman_s_q"] for s in (0, 1) for r in recs[("0.2", s)] if r["epoch"] in (45, 60)]; print("INFO noise pooled at epochs 45 and 60 (4 values):", np.round(vals, 3)); assert 0.015 <= min(vals) and max(vals) <= 0.035
# within-tensor
w = [x["median_conv_tensor_spearman_s_q"] for ln in ("0.0", "0.2") for x in sel(ln)]; chk("within-tensor records counted (epoch>=5, 4 runs)", len(w), 24, 0); chk("within-tensor min", min(w), -0.021, 0.0006); chk("within-tensor max", max(w), 0.007, 0.0006)
# saturation
q = [r["mean_q"] for s in (0, 1) for r in recs[("0.2", s)] if r["epoch"] >= 30]; chk("noise mean q-hat min (epoch>=30)", min(q), 0.95, 0.0051); chk("  max", max(q), 0.97, 0.0051)
# simulation statements (seeded; same estimator as noise_proxy_diagnostic.direct_noise_fraction)
rng = np.random.default_rng(0); K = 16
def qhat(g):
    sg = g.sum(0); sg2 = (g * g).sum(0); ms = sg2 / K; mu = sg / K; var = np.maximum((sg2 - K * mu * mu) / (K - 1), 0); return np.minimum(var / (ms + 1e-12), 1.0)
chk("pure-noise mean q-hat at K=16 (simulated)", qhat(rng.standard_normal((K, 2_000_000))).mean(), 0.969, 0.003)
for a, b, lo in ((1, 19, .29), (1, 9, .47)):
    f = rng.beta(a, b, 200_000); g = np.sqrt(f) + np.sqrt(1 - f) * rng.standard_normal((K, 200_000)); chk(f"ceiling Beta({a},{b})", stats.spearmanr(1 - f, qhat(g))[0], lo, 0.02)
# training integrity vs earlier Adam-NV runs (20% noise)
for s in (0, 1):
    a = pd.read_csv(f"{R16}/exp16/proxy_train_ln0.2_seed{s}.csv"); b = pd.read_csv(f"{R14}/Label_Diagnostic/adam_nv_scheduleconstant_sigma0.0_ln0.2_seed{s}.csv")
    chk(f"max |val_acc diff| vs earlier Adam-NV, seed {s}", float(np.abs(a.val_acc - b.val_acc).max()), 0.0, 0)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
