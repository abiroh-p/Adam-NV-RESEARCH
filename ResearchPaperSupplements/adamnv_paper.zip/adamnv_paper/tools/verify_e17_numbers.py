"""Recompute every Experiment 17 (ViT-tiny, second architecture) number typed in main.tex from the raw logs.
Run: E17_ROOT=<folder with the four log folders> python3 verify_e17_numbers.py
Folders: exp17_logs_1 (clean: adam, adam_nv), exp17_logs_2 (clean: constant 0.85), exp17_logs_3 (20% noise: adam, adam_nv), logs_exp17_vit_noisy_2 (20% noise: constant 0.85); seeds 0-4.
"""
import os, sys, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp07 as e7
R = os.environ.get("E17_ROOT", "/home/claude/e17"); BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
F = {"0.0": {"adam": "exp17_logs_1", "adam_nv": "exp17_logs_1", "adam_nv_fixed": "exp17_logs_2"}, "0.2": {"adam": "exp17_logs_3", "adam_nv": "exp17_logs_3", "adam_nv_fixed": "logs_exp17_vit_noisy_2"}}
def load(o, ln):
    out = {}
    for s in range(5):
        p = f"{R}/{F[ln][o]}/{o}_scheduleconstant_sigma0.0{'_ln0.2' if ln == '0.2' else ''}_seed{s}.csv"; df = pd.read_csv(p)
        assert len(df) == 60 and list(df.epoch) == list(range(1, 61)) and not df.isna().any().any(), p; out[s] = df
    return out
D = {(o, ln): load(o, ln) for ln in F for o in F[ln]}
def tab(m, ln): return {o: {s: e7.METRICS[m][1](d) for s, d in D[(o, ln)].items()} for o in F[ln]}
pairs = [("adam_nv", "adam"), ("adam_nv_fixed", "adam"), ("adam_nv", "adam_nv_fixed")]
def family(m, ln):
    t = tab(m, ln); rs = [e7.contrast(t, a, b) for a, b in pairs]; return t, rs, e7.holm([r["p"] for r in rs])
for ln, m, exp in (("0.0", "val5", dict(A=(79.79, .69), N=(80.27, .47), c=[(.48, -.06, 1.03, .14, 4), (.02, -.88, .92, None, None), (.46, .07, .86, .09, 5)])),
                   ("0.2", "mem5", dict(A=(52.18, 5.15), N=(56.03, 4.57), c=[(3.85, 2.72, 4.98, .002, 5), (2.54, .31, 4.77, .07, 5), (1.31, -1.71, 4.34, None, None)]))):
    t, rs, adj = family(m, ln)
    for o, (mm, sd) in (("adam", exp["A"]), ("adam_nv", exp["N"])):
        v = np.array(list(t[o].values())); chk(f"{ln} {m} {o} mean", v.mean(), mm); chk("  sd", v.std(ddof=1), sd)
    for (a, b), r, h, (mean, lo, hi, hp, up) in zip(pairs, rs, adj, exp["c"]):
        chk(f"{ln} {m} {a}-{b}", r["mean"], mean); chk("  lo", r["lo"], lo); chk("  hi", r["hi"], hi)
        if hp is not None: chk("  Holm p", h, hp, 0.0051 if hp > .01 else 0.0006)
        if up is not None: chk("  up", r["up"], up, 0)
# secondary: noisy val and clean-subset accuracy
for m, (mean, lo, hi) in {"val5": (-.25, -1.73, 1.23), "clean5": (.73, .59, .87)}.items():
    t = tab(m, "0.2"); r = e7.contrast(t, "adam_nv", "adam"); chk(f"0.2 {m} NV-Adam", r["mean"], mean); chk("  lo", r["lo"], lo); chk("  hi", r["hi"], hi)
# F/M and bootstrap
t = tab("mem5", "0.2"); M = np.array([t["adam_nv"][s] - t["adam"][s] for s in range(5)]); Fv = np.array([t["adam_nv_fixed"][s] - t["adam"][s] for s in range(5)])
chk("F/M", Fv.mean() / M.mean(), 0.66, 0.006); rng = np.random.default_rng(0); b = np.array([Fv[i].mean() / M[i].mean() for i in (rng.integers(0, 5, 5) for _ in range(20000))])
chk("bootstrap F/M lo", np.percentile(b, 2.5), 0.27, 0.0051); chk("bootstrap F/M hi", np.percentile(b, 97.5), 1.16, 0.0051)
# min detectable clean effect (n=5, 80% power)
from scipy import stats
d = np.array([tab("val5", "0.0")["adam_nv"][s] - tab("val5", "0.0")["adam"][s] for s in range(5)]); chk("min detectable clean effect (pp)", (stats.t.ppf(.975, 4) + stats.t.ppf(.8, 4)) * d.std(ddof=1) / np.sqrt(5), 0.7, 0.051)
# epoch-5 accuracy statement and logged beta1
chk("min val acc at epoch 5 over all 30 runs (>0.50)", min(df.val_acc.iloc[4] for v in D.values() for df in v.values()), 0.50, 0.06); assert min(df.val_acc.iloc[4] for v in D.values() for df in v.values()) > 0.5
for ln, pv in (("0.0", 0.79), ("0.2", 0.80)): chk(f"Adam-NV logged tensor-mean beta1, time-avg, noise {ln}", np.mean([D[('adam_nv', ln)][s].beta1_mean.mean() for s in range(5)]), pv, 0.0051)
# pilot (logs not retained; values as printed by the authors): epoch-1 accuracies must equal those of the main clean seed-0 runs
pilot = {"adam": [0.434, 0.502, 0.553, 0.611, 0.632], "adam_nv": [0.442, 0.513, 0.571, 0.611, 0.63], "adam_nv_fixed": [0.45, 0.519, 0.554, 0.619, 0.636]}
for o, vals in pilot.items():
    chk(f"pilot epoch-1 val acc equals main clean seed-0 run, {o}", vals[0], float(pd.read_csv(f"{R}/{F['0.0'][o]}/{o}_scheduleconstant_sigma0.0_seed0.csv").val_acc.iloc[0]), 0.0006)
    assert vals[4] >= 0.35 and all(b > a for a, b in zip(vals, vals[1:]))   # go criterion: rises and reaches >= 0.35 at epoch 5
    assert 0.63 <= round(vals[4], 2) <= 0.64
print("ViT tensors (from models_alt, run separately): 80 tensors, 52 of rank<=1 (13,258 of 1,806,538 elements)")
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
