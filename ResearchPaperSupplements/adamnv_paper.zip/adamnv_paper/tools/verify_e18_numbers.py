"""Recompute every Experiment 18 (ViT constant-beta1 sweep, 20% noise) number typed in main.tex (Table X and Section V-H).
Run: E18_ROOT=<folder with exp18_logs_1, logs_exp18_vit_b070, logs_exp18_vit_b092, logs_exp18_vit_b095> E17_ROOT=<Exp. 17 folders> python3 verify_e18_numbers.py
"""
import os, sys, numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp07 as e7
R18 = os.environ.get("E18_ROOT", "/home/claude/e18"); R17 = os.environ.get("E17_ROOT", "/home/claude/e17"); BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
S = range(5)
def L(opt, d):
    out = {}
    for s in S:
        df = pd.read_csv(f"{d}/{opt}_scheduleconstant_sigma0.0_ln0.2_seed{s}.csv"); assert len(df) == 60 and list(df.epoch) == list(range(1, 61)) and not df.isna().any().any(); out[s] = df
    return out
mem5 = e7.METRICS["mem5"][1]; val5 = e7.METRICS["val5"][1]
dirs = {0.70: f"{R18}/logs_exp18_vit_b070", 0.80: f"{R18}/exp18_logs_1", 0.85: f"{R17}/logs_exp17_vit_noisy_2", 0.92: f"{R18}/logs_exp18_vit_b092", 0.95: f"{R18}/logs_exp18_vit_b095"}
arms = {c: L("adam_nv_fixed", d) for c, d in dirs.items()}; A = L("adam", f"{R17}/exp17_logs_3"); N = L("adam_nv", f"{R17}/exp17_logs_3")
tab = {"adam": {s: mem5(d) for s, d in A.items()}, "nv": {s: mem5(d) for s, d in N.items()}}; vtab = {"adam": {s: val5(d) for s, d in A.items()}, "nv": {s: val5(d) for s, d in N.items()}}
for c, x in arms.items(): tab[c] = {s: mem5(d) for s, d in x.items()}; vtab[c] = {s: val5(d) for s, d in x.items()}
paper = {  # mean, sd, F, Flo, Fhi, up, D, Dlo, Dhi
 "adam": (52.18, 5.15), "nv": (56.03, 4.57),
 0.70: (58.11, 5.14, 5.93, -1.98, 13.84, 4, -2.08, -9.88, 5.71), 0.80: (57.01, 4.03, 4.83, 1.91, 7.75, 5, -0.98, -3.91, 1.95), 0.85: (54.71, 5.27, 2.54, 0.31, 4.77, 5, 1.31, -1.71, 4.34),
 0.92: (51.88, 5.23, -0.30, -2.89, 2.30, 1, 4.15, 1.43, 6.86), 0.95: (47.34, 3.26, -4.84, -9.76, 0.08, 1, 8.69, 4.23, 13.14)}
for k in ("adam", "nv"):
    v = np.array(list(tab[k].values())); chk(f"{k} mean", v.mean(), paper[k][0]); chk("  sd", v.std(ddof=1), paper[k][1])
M = e7.contrast(tab, "nv", "adam"); chk("M", M["mean"], 3.85); chk("M lo", M["lo"], 2.72); chk("M hi", M["hi"], 4.98); chk("M up", M["up"], 5, 0)
for c in dirs:
    p = paper[c]; v = np.array(list(tab[c].values())); chk(f"{c} mean", v.mean(), p[0]); chk("  sd", v.std(ddof=1), p[1])
    F = e7.contrast(tab, c, "adam"); D = e7.contrast(tab, "nv", c)
    chk("  F", F["mean"], p[2]); chk("  F lo", F["lo"], p[3]); chk("  F hi", F["hi"], p[4]); chk("  F up", F["up"], p[5], 0)
    chk("  D", D["mean"], p[6]); chk("  D lo", D["lo"], p[7]); chk("  D hi", D["hi"], p[8])
# Holm family {F,D} x {0.70, 0.80, 0.95}
fam = []; names = []
for c in (0.70, 0.80, 0.95):
    for nm, (a, b) in (("F", (c, "adam")), ("D", ("nv", c))): names.append((nm, c)); fam.append(e7.contrast(tab, a, b)["p"])
adj = dict(zip(names, e7.holm(fam)))
for key, p in {("F", 0.70): 0.32, ("F", 0.80): 0.050, ("F", 0.95): 0.21, ("D", 0.70): 0.81, ("D", 0.80): 0.81, ("D", 0.95): 0.034}.items(): chk(f"Holm {key}", adj[key], p, 0.0051 if p > .05 else 0.0006)
F80 = e7.contrast(tab, 0.80, "adam")["mean"]; chk("F/M at 0.80", F80 / M["mean"], 1.25, 0.006)
Fv = np.array([tab[0.80][s] - tab["adam"][s] for s in S]); Mv = np.array([tab["nv"][s] - tab["adam"][s] for s in S]); rng = np.random.default_rng(0)
b = np.array([Fv[i].mean() / Mv[i].mean() for i in (rng.integers(0, 5, 5) for _ in range(20000))]); chk("bootstrap F/M lo", np.percentile(b, 2.5), 0.75, 0.0051); chk("bootstrap F/M hi", np.percentile(b, 97.5), 1.76, 0.0051)
# seed-level dose-response over the six constants (0.90 = Adam)
cs = np.array([0.70, 0.80, 0.85, 0.90, 0.92, 0.95]); T = pd.DataFrame({c: [tab[c][s] if c != 0.90 else tab["adam"][s] for s in S] for c in cs})
sl = np.array([np.polyfit(cs, T.iloc[i].values.astype(float), 1)[0] for i in range(5)]); m = sl.mean(); se = sl.std(ddof=1) / np.sqrt(5); t = stats.t.ppf(.975, 4)
chk("per-seed slope mean", m, -39, 0.51); chk("  lo", m - t * se, -74, 0.51); chk("  hi", m + t * se, -5, 0.51); chk("  seeds with negative slope", int((sl < 0).sum()), 5, 0)
rho = [stats.spearmanr(cs, T.iloc[i].values.astype(float))[0] for i in range(5)]; assert all(r < 0 for r in rho)
# interpolated matched constant
mc = np.array([T[c].mean() for c in cs]); nv_mean = np.mean(list(tab["nv"].values())); chk("interpolated matched beta1", float(np.interp(-nv_mean, -mc[1:3], cs[1:3])), 0.82, 0.0051)
# validation accuracy of the constants
vals = [e7.contrast(vtab, c, "adam") for c in dirs]; chk("val diff min", min(v["mean"] for v in vals), -0.69, 0.0051); chk("val diff max", max(v["mean"] for v in vals), -0.36, 0.0051); assert all(v["lo"] <= 0 <= v["hi"] for v in vals)
chk("memorization slope epochs 51-60 (0.80), pp/epoch ~0.5", np.polyfit(np.arange(51, 61), np.mean([100 * arms[0.80][s].train_corrupt_noisy_label_acc.values[50:60] for s in S], 0), 1)[0], 0.5, 0.06)
cl = lambda d: 100 * d.train_clean_subset_acc.tail(5).mean()
cseq = [np.mean([cl(arms[c][s]) for s in S]) if c != 0.90 else np.mean([cl(A[s]) for s in S]) for c in (0.70, 0.80, 0.85, 0.90, 0.92, 0.95)]
assert all(x > y for x, y in zip(cseq, cseq[1:])), cseq   # clean-subset training accuracy falls monotonically as beta1 rises ("as do the lower constants")
cn = e7.contrast({"a": {s: cl(N[s]) for s in S}, "b": {s: cl(A[s]) for s in S}}, "a", "b"); chk("clean-subset NV-Adam", cn["mean"], 0.73); chk("  lo", cn["lo"], 0.59); chk("  hi", cn["hi"], 0.87)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
