"""Recompute every Experiment 19 (null run) number typed in main.tex.
Run: E19_ROOT=<folder with logs_exp19_null_A/B> E14_ROOT=<folder with Label_Diagnostic, logs_exp07_*, logs_exp14_*> python3 verify_e19_numbers.py
"""
import os, sys, numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp07 as e7
R19 = os.environ.get("E19_ROOT", "/home/claude/e19"); R14 = os.environ.get("E14_ROOT", "/home/claude/e14"); BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
S = range(8); fn = e7.METRICS["mem5"][1]
def load(opt, dirs):
    out = {}
    for s in S:
        for d in dirs:
            p = os.path.join(d, e7.NAME.format(opt=opt, seed=s))
            if os.path.isfile(p):
                df = pd.read_csv(p); assert len(df) == 60 and list(df.epoch) == list(range(1, 61)) and not df.isna().any().any(), p; out[s] = fn(df); break
    assert len(out) == 8, (opt, sorted(out)); return out
base = [f"{R14}/{d}" for d in ["Label_Diagnostic", "logs_exp07_A", "logs_exp07_B", "exp07_log_C/log_exp07_C"]]
t = {"adam": load("adam", base), "nv": load("adam_nv", base), "null": load("adam_nv_fixed", [f"{R19}/logs_exp19_null_A", f"{R19}/logs_exp19_null_B"]),
     "one": load("adam_nv", [f"{R14}/logs_exp14_onedim_A", f"{R14}/logs_exp14_onedim_C"]), "rest": load("adam_nv", [f"{R14}/logs_exp14_rest_B", f"{R14}/logs_exp14_rest_C"])}
z = e7.contrast({"a": t["null"], "b": t["adam"]}, "a", "b"); chk("null - Adam", z["mean"], -0.15); chk("  lo", z["lo"], -0.88); chk("  hi", z["hi"], 0.58); chk("  up", z["up"], 5, 0)
x = np.array([t["null"][s] - t["adam"][s] for s in S]); chk("null paired SD", x.std(ddof=1), 0.88)
Mv = np.array([t["nv"][s] - t["adam"][s] for s in S]); chk("Adam-NV - Adam paired SD", Mv.std(ddof=1), 0.95)
assert not (z["lo"] > -0.5 and z["hi"] < 0.5) and (z["lo"] > -1.0 and z["hi"] < 1.0)   # not inside the registered +/-0.5 margin (inconclusive); inside a +/-1 margin that was not registered
for lab, (a, b, mean, lo, hi) in {"F1'": ("one", "null", 1.34, 0.71, 1.97), "F2'": ("rest", "null", 2.88, 2.07, 3.68)}.items():
    r = e7.contrast({"a": t[a], "b": t[b]}, "a", "b"); chk(lab, r["mean"], mean); chk("  lo", r["lo"], lo); chk("  hi", r["hi"], hi)
M2 = e7.contrast({"a": t["nv"], "b": t["null"]}, "a", "b")["mean"]; chk("M' (Adam-NV - null)", M2, 4.06)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
