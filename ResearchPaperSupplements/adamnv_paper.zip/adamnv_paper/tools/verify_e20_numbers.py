"""Recompute every Experiment 20 (constant beta1 on the one-dimensional tensors) number typed in main.tex.
Run: E20_ROOT=<folder with exp20_logs_1/2> E14_ROOT=<folder with Label_Diagnostic, logs_exp07_*, logs_exp14_onedim_*> python3 verify_e20_numbers.py
"""
import os, sys, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp07 as e7
R20 = os.environ.get("E20_ROOT", "/home/claude/e20"); R14 = os.environ.get("E14_ROOT", "/home/claude/e14"); BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
S = range(8); fn = e7.METRICS["mem5"][1]
def load(opt, dirs):
    out = {}; b1 = []
    for s in S:
        for d in dirs:
            p = os.path.join(d, e7.NAME.format(opt=opt, seed=s))
            if os.path.isfile(p):
                df = pd.read_csv(p); assert len(df) == 60 and list(df.epoch) == list(range(1, 61)) and not df.isna().any().any(), p; out[s] = fn(df); b1.append(df.beta1_mean.mean()) if "beta1_mean" in df else None; break
    assert len(out) == 8, (opt, sorted(out)); return out, b1
base = [f"{R14}/{d}" for d in ["Label_Diagnostic", "logs_exp07_A", "logs_exp07_B", "exp07_log_C/log_exp07_C"]]
a, _ = load("adam", base); o, _ = load("adam_nv", [f"{R14}/logs_exp14_onedim_A", f"{R14}/logs_exp14_onedim_C"]); c, b1 = load("adam_nv", [f"{R20}/exp20_logs_1", f"{R20}/exp20_logs_2"])
t = {"adam": a, "one": o, "c": c}
F1 = e7.contrast(t | {}, "one", "adam"); C = e7.contrast(t, "c", "adam"); E = e7.contrast(t, "one", "c")
chk("F1", F1["mean"], 1.19); chk("C", C["mean"], 0.37); chk("  C lo", C["lo"], -0.90); chk("  C hi", C["hi"], 1.64); chk("  C up", C["up"], 4, 0)
chk("C/F1", C["mean"] / F1["mean"], 0.31, 0.006); chk("E", E["mean"], 0.82); chk("  E lo", E["lo"], -0.02); chk("  E hi", E["hi"], 1.66); chk("  E up", E["up"], 7, 0)
adj = e7.holm([C["p"], E["p"]]); chk("Holm E", adj[1], 0.11, 0.0051); print(f"INFO Holm C = {adj[0]:.3f}")
assert F1["lo"] > 0 and C["mean"] < 0.5 * F1["mean"] and not E["lo"] > 0   # rule: 'adaptivity needed' not met because the CI of E includes 0 -> partly/inconclusive
chk("expected logged beta1_mean (41*0.79+21*0.9)/62", float(np.mean(b1)), (41 * 0.79 + 21 * 0.9) / 62, 0.0006)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
