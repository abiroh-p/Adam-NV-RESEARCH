"""Recompute every Experiment 21 (noise-proxy diagnostic v2) number typed in main.tex.
Run: E21_ROOT=<folder with logs_exp21_A, logs_exp21_B> E16_ROOT=<folder with exp16/> E14_ROOT=<folder with Label_Diagnostic> python3 verify_e21_numbers.py
"""
import os, sys, json, numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import analyze_exp21 as an
R21 = os.environ.get("E21_ROOT", "/home/claude/e21logs/e2_noisy_gradient"); R16 = os.environ.get("E16_ROOT", "/home/claude/e16"); R14 = os.environ.get("E14_ROOT", "/home/claude/e14"); BAD = []
def chk(name, a, p, tol=0.0051):
    ok = abs(a - p) <= tol; BAD.append((name, a, p)) if not ok else None; print(f"{'OK ' if ok else 'XX '} {name}: computed {a:.4f} | paper {p}")
D = [f"{R21}/logs_exp21_A", f"{R21}/logs_exp21_B"]; S = range(5)
runs = {(ln, s): an.load(D, ln, s) for ln in ("0.0", "0.2") for s in S}
assert all(runs[k] and sorted(runs[k]) == an.CK and all(len(r["tensors"]) == 62 and r["k_batches"] == 64 for r in runs[k].values()) for k in runs)
def ci(x):
    x = np.asarray([v for v in x if v == v], float); m = x.mean(); se = x.std(ddof=1) / np.sqrt(len(x)); t = stats.t.ppf(.975, len(x) - 1); return m, m - t * se, m + t * se
def per(ln, eps, key, fn=None):
    return [np.nanmean([ (fn or (lambda r: an.stats_row(r)[key]))(runs[(ln, s)][e]) for e in eps]) for s in S]
late = (30, 45, 60); early = (5, 10)
for ln, rel_late, rstar, r0, rrel, rrms, rrms0, btw in (
        ("0.0", (0.04,), (-0.02, -0.03, -0.01), 0.01, 0.44, (0.22, 0.21, 0.24), -0.02, (0.26, 0.16, 0.35)),
        ("0.2", (0.04,), (-0.01, -0.02, -0.01), 0.01, 0.41, (0.22, 0.21, 0.23), -0.04, (-0.14, -0.28, -0.01))):
    chk(f"{ln} mean reliability, epochs 30-60", np.mean(per(ln, late, "rel")), rel_late[0])
    assert np.mean(per(ln, late, "rel")) < 0.2    # registered rule: UNRESOLVED
    m, lo, hi = ci(per(ln, early, "Rstar")); chk(f"{ln} R* epochs 5,10", m, rstar[0]); chk("  lo", lo, rstar[1]); chk("  hi", hi, rstar[2]); assert hi < 0.1
    chk(f"{ln} reliability epochs 5,10", np.mean(per(ln, early, "rel")), rrel); chk(f"{ln} R0* epochs 5,10 (lambda=0)", ci(per(ln, early, "R0star"))[0], r0)
    m, lo, hi = ci(per(ln, late, "Rrms")); chk(f"{ln} r(s,rms) epochs 30-60", m, rrms[0]); chk("  lo", lo, rrms[1]); chk("  hi", hi, rrms[2])
    chk(f"{ln} r(s0,rms) lambda=0, epochs 30-60", ci(per(ln, late, "x", lambda r: an.med(r, "r_s0_rms")))[0], rrms0)
    m, lo, hi = ci(per(ln, late, "between_s_qu")); chk(f"{ln} between-tensor r(s,qu) epochs 30-60", m, btw[0]); chk("  lo", lo, btw[1]); chk("  hi", hi, btw[2])
# reliability trajectory and saturation statements
chk("clean conv reliability epoch 1", np.mean([an.stats_row(runs[("0.0", s)][1])["rel"] for s in S]), 0.7, 0.0151)
for ln in ("0.0", "0.2"): v = np.mean([an.stats_row(runs[(ln, s)][45])["rel"] for s in S]); print(f"INFO reliability epoch 45, {ln}: {v:.3f}"); assert 0.005 <= v <= 0.025
chk("noise mean q (unclamped) epoch 60", np.mean([runs[("0.2", s)][60]["mean_qu"] for s in S]), 0.999, 0.0006)
# pooled replication of Exp. 16 (same estimator, clamped, first K/4 batches)
chk("E21 pooled s-q16, clean epoch 60", np.mean([runs[("0.0", s)][60]["spearman_s_q16"] for s in S]), 0.74); chk("E21 pooled s-q16, noise epoch 60", np.mean([runs[("0.2", s)][60]["spearman_s_q16"] for s in S]), 0.02)
e16c = np.mean([json.loads(l)["spearman_s_q"] for s in (0, 1) for l in open(f"{R16}/exp16/proxy_diag_ln0.0_seed{s}.jsonl") if json.loads(l)["epoch"] == 60]); chk("E16 pooled, clean epoch 60", e16c, 0.79)
e16n = np.mean([json.loads(l)["spearman_s_q"] for s in (0, 1) for l in open(f"{R16}/exp16/proxy_diag_ln0.2_seed{s}.jsonl") if json.loads(l)["epoch"] == 60]); chk("E16 pooled, noise epoch 60", e16n, 0.02)
# training equivalence at 20% noise
for s in S:
    tr = pd.read_csv(f"{[d for d in D if os.path.isfile(f'{d}/proxy2_train_ln0.2_seed{s}.csv')][0]}/proxy2_train_ln0.2_seed{s}.csv")
    ref = [f"{R14}/{d}/adam_nv_scheduleconstant_sigma0.0_ln0.2_seed{s}.csv" for d in ("Label_Diagnostic", "exp07_log_C/log_exp07_C")]; ref = [r for r in ref if os.path.isfile(r)][0]
    chk(f"max |val_acc diff| vs earlier Adam-NV, seed {s}", float(np.abs(tr.val_acc.values - pd.read_csv(ref).val_acc.values).max()), 0.0, 0)
print("\nMISMATCHES:", len(BAD)); [print(x) for x in BAD]; sys.exit(1 if BAD else 0)
