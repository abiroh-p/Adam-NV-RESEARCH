"""Recompute every table number of the paper from the raw logs and compare with the values typed in main.tex."""
import glob, os, re, sys, json
import numpy as np, pandas as pd
import analyze_exp07 as e7
sys.path.insert(0, '/home/claude/exp10/analysis')
import analyze_exp10 as e10

BAD = []
def chk(name, actual, expected, tol=0.006):
    ok = abs(actual - expected) <= tol
    if not ok: BAD.append((name, actual, expected))
    print(f"{'OK ' if ok else 'XX '} {name}: computed {actual:.3f} | paper {expected}")

# ---------- Table II (clean CIFAR-10, lr 1e-3, 10 seeds)
D = pd.read_csv('/home/claude/e1_10seed_v3.csv')
exp2 = {'adam':(93.15,0.11,19.0,26.31),'adam_nv':(93.20,0.15,18.6,26.39),'adamw':(93.22,0.15,18.4,26.43),'gono':(92.44,0.14,25.4,30.39),'adabelief':(92.44,0.17,24.3,26.67)}
for o,(m,sd,ep,auc) in exp2.items():
    g = D[D.opt==o]
    chk(f"T2 {o} n",len(g),10,0); chk(f"T2 {o} mean",g.last5.mean(),m,0.006); chk(f"T2 {o} sd",g.last5.std(),sd,0.006)
    chk(f"T2 {o} ep90",g.ep90.mean(),ep,0.06); chk(f"T2 {o} AUC",g.vauc.mean(),auc,0.006)
a = D[D.opt=='adam'].set_index('seed').last5; n = D[D.opt=='adam_nv'].set_index('seed').last5
chk("E1 NV-Adam seeds0-3 (text +0.12)", (n[:4]-a[:4]).mean(), 0.12, 0.006)
chk("E1 NV-Adam all", (n-a).mean(), 0.06, 0.006)

# ---------- Exp05/06 Table IV (4 seeds) and Table III (10 seeds)
dirs = ['/home/claude/logs/exp05_logs_adam','/home/claude/logs/exp05_logs_adamnv','/home/claude/l6','/home/claude/e10/A','/home/claude/e10/B','/home/claude/e10/C']
data = e10.load(dirs, set(range(10)), 60)
def l5(arm, seeds): return np.array([data[arm][s]['last5'] for s in seeds])
t3 = {'adam':(93.02,0.16),'adam_nv':(93.19,0.16),'adam_b083':(93.07,0.21),'adam_b080':(93.08,0.18)}
for arm,(m,sd) in t3.items():
    v = l5(arm, range(10)); chk(f"T3 {arm} mean",v.mean(),m); chk(f"T3 {arm} sd",v.std(ddof=1),sd)
t4 = {'adam':(92.94,0.11),'adam_nv':(93.13,0.14),'adam_b083':(93.11,0.15),'adam_b080':(93.14,0.16)}
for arm,(m,sd) in t4.items():
    v = l5(arm, range(4)); chk(f"T4(3e-3) {arm} mean",v.mean(),m); chk(f"T4(3e-3) {arm} sd",v.std(ddof=1),sd)
for a_,b_,mean,lo,hi,up in [('adam_nv','adam',0.17,0.05,0.29,9),('adam_b083','adam',0.06,-0.11,0.22,7),('adam_b080','adam',0.07,-0.11,0.24,8),('adam_nv','adam_b083',0.12,-0.02,0.25,8),('adam_nv','adam_b080',0.11,-0.04,0.25,8)]:
    r = e10.contrast(data,a_,b_,'last5'); chk(f"T3 {a_}-{b_} mean",r['mean'],mean); chk(f"T3 {a_}-{b_} lo",r['lo'],lo,0.011); chk(f"T3 {a_}-{b_} hi",r['hi'],hi,0.011); chk(f"T3 {a_}-{b_} up",r['up'],up,0)
sub = {a:{s:v for s,v in data[a].items() if s>=4} for a in e10.ARMS}
for a_,b_,mean in [('adam_nv','adam',0.16),('adam_b083','adam',-0.02),('adam_b080','adam',-0.03)]:
    chk(f"seeds4-9 {a_}-{b_}", e10.contrast(sub,a_,b_,'last5')['mean'], mean)
chk("Adam seeds0-3 mean (text 92.94)", l5('adam',range(4)).mean(), 92.94); chk("Adam seeds4-9 mean (text 93.07)", l5('adam',range(4,10)).mean(), 93.07)
# final-epoch NV-Adam (text +0.16, Holm 0.13)
pairs=[("adam_nv","adam"),("adam_b083","adam"),("adam_b080","adam"),("adam_nv","adam_b083"),("adam_nv","adam_b080")]
res=[e10.contrast(data,a_,b_,'final') for a_,b_ in pairs]; adj=e10.holm([r['p'] for r in res])
chk("final-epoch NV-Adam", res[0]['mean'], 0.16, 0.006); chk("final-epoch NV-Adam Holm", adj[0], 0.13, 0.006)

# ---------- Label noise (Table VIII)
ORIG='/home/claude/repo/e2_noisy_gradient/logs/Label_Diagnostic'; E7='/home/claude/e7'; E8='/home/claude/e8'; E9='/home/claude/e9'; E11='/home/claude/e11'; E12='/home/claude/e12'
NAME="{opt}_scheduleconstant_sigma0.0_ln0.2_seed{seed}.csv"
SM="adam_nv_scheduleconstant_sigma0.0_responsesmooth_betamax0.999_ln0.2_seed{seed}.csv"
arms = {
 'adam':(NAME,'adam',[ORIG,E7+'/A/logs_exp07_A',E7+'/B/logs_exp07_B']),
 'nv':(NAME,'adam_nv',[ORIG,E7+'/C/exp07_log_C/log_exp07_C']),
 'c081':(NAME,'adam_nv_fixed',[E7+'/A/logs_exp07_A',E7+'/B/logs_exp07_B']),
 'c078':(NAME,'adam_nv_fixed',[E8+'/A/logs_exp08_b078_A',E8+'/B/exp08_logs_B/logs_exp08_b078_B']),
 'c070':(NAME,'adam_nv_fixed',[E8+'/A/logs_exp08_b070_A',E8+'/B/exp08_logs_B/logs_exp08_b070_B',E8+'/C/logs_exp08_b070_C']),
 'c092':(NAME,'adam_nv_fixed',[E12+'/1/logs_exp12_b092_1',E12+'/2/logs_exp12_b092_2']),
 'c095':(NAME,'adam_nv_fixed',[E12+'/3/logs_exp12_b095_1',E12+'/4/logs_exp12_b095_2']),
 'smooth':(SM,'adam_nv',[E9+'/A/logs_exp09_A',E9+'/B/logs_exp09_B']),
 'step':(NAME,'adam_nv',[E11+'/A/logs_exp11_step_A',E11+'/C/logs_exp11_step_C']),
 'fixed':(NAME,'adam_nv',[E11+'/B/logs_exp11_fixed_B',E11+'/C/logs_exp11_fixed_C']),
 'tm':(NAME,'adam_nv',['/home/claude/e13/A/logs_exp13_tm_A','/home/claude/e13/B/logs_exp13_tm_B']),
}
M = {k:{} for k in ['mem5','val5','clean5','valpeak']}
tab = {k:{m:{} for m in M} for k in arms}
for k,(tmpl,opt,ds) in arms.items():
    for s in range(8):
        for d in ds:
            p=os.path.join(d,tmpl.format(opt=opt,seed=s))
            if os.path.isfile(p):
                df=pd.read_csv(p); assert len(df)==60,(p,len(df))
                for m,(_,fn) in e7.METRICS.items(): tab[k][m][s]=fn(df)
                break
    assert len(tab[k]['mem5'])==8,(k,len(tab[k]['mem5']))
paper8 = {  # arm: (mem mean, mem sd, val, clean, delta, lo, hi, up)
 'adam':(79.58,1.01,78.79,98.73,None,None,None,None),'c081':(80.22,0.99,78.80,98.74,0.64,-0.40,1.67,7),'c078':(80.35,1.11,78.85,98.75,0.77,-0.45,1.99,6),
 'c070':(80.41,1.30,78.53,98.77,0.83,-0.57,2.22,6),'c092':(80.03,1.79,78.58,98.74,0.44,-0.82,1.71,5),'c095':(78.56,1.06,78.61,98.70,-1.03,-2.21,0.16,2),
 'nv':(83.49,0.54,78.84,98.84,3.91,3.11,4.71,8),'smooth':(78.11,0.89,78.37,98.72,-1.47,-2.40,-0.55,0),'step':(81.98,0.69,78.59,98.80,2.40,1.20,3.60,8),'fixed':(82.40,0.73,78.59,98.78,2.81,2.18,3.44,8),'tm':(82.13,0.70,78.61,98.83,2.55,1.56,3.53,8)}
for k,(mm,sd,val,cl,dl,lo,hi,up) in paper8.items():
    v=np.array([tab[k]['mem5'][s] for s in range(8)])
    chk(f"T8 {k} mem",v.mean(),mm); chk(f"T8 {k} sd",v.std(ddof=1),sd); chk(f"T8 {k} val",np.mean(list(tab[k]['val5'].values())),val); chk(f"T8 {k} clean",np.mean(list(tab[k]['clean5'].values())),cl)
    if dl is not None:
        r=e7.contrast({'x':tab[k]['mem5'],'adam':tab['adam']['mem5']},'x','adam'); chk(f"T8 {k} delta",r['mean'],dl); chk(f"T8 {k} lo",r['lo'],lo,0.011); chk(f"T8 {k} hi",r['hi'],hi,0.011); chk(f"T8 {k} up",r['up'],up,0)
def con(a,b,m='mem5'): return e7.contrast({'a':tab[a][m],'b':tab[b][m]},'a','b')
for a_,b_,mean,lo,hi in [('nv','c081',3.27,2.39,4.16),('nv','c078',3.14,2.16,4.13),('nv','c070',3.08,1.92,4.24),('nv','smooth',5.38,4.55,6.21),('nv','step',1.51,0.93,2.08),('nv','fixed',1.10,0.39,1.81),('fixed','step',0.41,-0.53,1.35),('nv','tm',1.36,0.83,1.90),('tm','step',0.15,-0.65,0.94),('tm','fixed',-0.27,-1.10,0.57),('smooth','c095',-0.45,-1.32,0.43),('smooth','c092',-1.91,-3.52,-0.30)]:
    r=con(a_,b_); chk(f"contrast {a_}-{b_}",r['mean'],mean); chk(f"  lo",r['lo'],lo,0.011); chk(f"  hi",r['hi'],hi,0.011)
chk("smooth val - adam (text -0.42)", np.mean(list(tab['smooth']['val5'].values()))-np.mean(list(tab['adam']['val5'].values())), -0.42, 0.011)
vals=[np.mean(list(tab[k]['val5'].values())) for k in tab]; peaks=[np.mean(list(tab[k]['valpeak'].values())) for k in tab]
print(f"INFO val range {min(vals):.2f}-{max(vals):.2f}; peak range {min(peaks):.2f}-{max(peaks):.2f}")
# constants dose response slope
xs=[];ys=[]
for k,b in [('c070',.70),('c078',.78),('c081',.81),('adam',.90),('c092',.92),('c095',.95)]:
    for v in tab[k]['mem5'].values(): xs.append(b); ys.append(v)
from scipy import stats
fit=stats.linregress(xs,ys); chk("dose slope",fit.slope,-5.7,0.06); chk("dose r",fit.rvalue,-0.38,0.006); chk("dose p",fit.pvalue,0.008,0.0006)
# ---------- beta1 distribution (Table VII)
recs=[[json.loads(x) for x in open(f)] for f in glob.glob(E11+'/C/logs_exp11_none_C/beta1_dist_none_seed?.jsonl')]
for e,(mn,md,q05,q01,mi,fr) in {1:(0.891,0.894,0.876,0.857,0.601,0.01),20:(0.893,0.898,0.871,0.846,0.486,0.03),40:(0.885,0.891,0.850,0.824,0.406,0.02),60:(0.881,0.887,0.845,0.818,0.436,0.02)}.items():
    g=lambda k: np.mean([r[e-1][k] for r in recs])
    chk(f"T7 e{e} mean",g('mean'),mn,0.0006); chk(f"T7 e{e} median",g('q50'),md,0.0006); chk(f"T7 e{e} q05",g('q05'),q05,0.0006); chk(f"T7 e{e} q01",g('q01'),q01,0.0006); chk(f"T7 e{e} min",g('min'),mi,0.0006); chk(f"T7 e{e} <0.7 %",100*g('frac_below_0.7'),fr,0.006)
# ---------- E13 (Table V) and Table VI from the regenerated repo CSV
b=pd.read_csv('/tmp/e1315.csv')
for c in ['mean_difference','ci95_low','ci95_high']: b[c+'_pp']=b[c]*100
e13=b[b.experiment=='E13'][['comparison','n_pairs','mean_difference_pp','ci95_low_pp','ci95_high_pp','p_paired_t_holm']]
print(e13.round(3).to_string())
# ---------- timing
t=pd.read_csv('/home/claude/tv2/results_v2/overhead_summary.csv').set_index('optimizer')
chk("timing NV step",t.loc['adam_nv','median_step_ms'],27.3,0.06); chk("timing Adam step",t.loc['adam','median_step_ms'],3.8,0.06)
chk("timing NV total",t.loc['adam_nv','median_total_ms'],126.5,0.06); chk("timing Adam total",t.loc['adam','median_total_ms'],108.0,0.06)
chk("timing ratio %",100*(t.loc['adam_nv','total_ratio_vs_ref']-1),17.1,0.06); chk("AdamW %",100*(t.loc['adamw','total_ratio_vs_ref']-1),0.4,0.06); chk("AdaBelief %",100*(t.loc['adabelief','total_ratio_vs_ref']-1),2.8,0.06)
chk("fwd_bwd NV",t.loc['adam_nv','median_fwd_bwd_ms'],99.0,0.06); chk("fwd_bwd Adam",t.loc['adam','median_fwd_bwd_ms'],104.2,0.06)
chk("state NV",t.loc['adam_nv','optimizer_state_mib'],170.5,0.06); chk("state Adam",t.loc['adam','optimizer_state_mib'],85.3,0.06)
chk("peak NV",t.loc['adam_nv','peak_alloc_mib'],914.1,0.06); chk("peak Adam",t.loc['adam','peak_alloc_mib'],828.5,0.06); chk("peak extra",t.loc['adam_nv','peak_extra_vs_ref_mib'],85.6,0.06)
print('\nMISMATCHES:',len(BAD))
for x in BAD: print(x)

# ---------- per-tensor table (Table beta1rank) from the Exp13 'none' runs
import collections
files=glob.glob('/home/claude/e13/C/logs_exp13_none_C/beta1_tensors_none_seed?.jsonl')
runs=[[json.loads(x) for x in open(f)] for f in files]
paper_rank={1:(41,9610,[0.867,0.810,0.763,0.753]),2:(1,5120,[0.717,0.703,0.749,0.781]),4:(20,11159232,[0.874,0.863,0.849,0.846])}
for k,(nt,ne,vals) in paper_rank.items():
    for e,v in zip([1,20,40,60],vals):
        got=np.mean([t['mean'] for run in runs for t in run[e-1]['tensors'] if len(t['shape'])==k])
        chk(f"rank{k} e{e}",got,v,0.0006)
    sel=[t for t in runs[0][0]['tensors'] if len(t['shape'])==k]; chk(f"rank{k} tensors",len(sel),nt,0); chk(f"rank{k} elements",sum(t['numel'] for t in sel),ne,0)
for e,v in zip([1,20,40,60],[0.867,0.825,0.790,0.784]):
    chk(f"all tensors e{e}",np.mean([t['mean'] for run in runs for t in run[e-1]['tensors']]),v,0.0006)
conv=[min(t['mean'] for run in runs for t in run[59]['tensors'] if len(t['shape'])==4)]; chk("lowest conv tensor mean e60",conv[0],0.64,0.006)
print('\nMISMATCHES (final):',len(BAD))
for x in BAD: print(x)
